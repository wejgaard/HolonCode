#!/bin/bash
cd `dirname $0`
tclsh holonCode/holoncode.tcl holonCode.hdb &
